package se233.Asteroids_Project;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import se233.Asteroids_Project.controller.GameController;
import se233.Asteroids_Project.model.Asset.PlayerProjectile;
import se233.Asteroids_Project.model.Entities.Asteroids;
import se233.Asteroids_Project.model.Entities.Boss;
import se233.Asteroids_Project.model.Entities.Minion;
import se233.Asteroids_Project.model.Entities.Player;
import se233.Asteroids_Project.model.Scoring;
import se233.Asteroids_Project.view.GameStage;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class ScoringTest {
    private Player mockPlayer;
    private final double SCREEN_WIDTH = 800;
    private final double SCREEN_HEIGHT = 600;
    private final double DELTA = 0.01;
    private final double INITIAL_ROTATION = -90;
    private GameController gameController;
    private GameController mockGameController;
    private GameStage mockGameStage;
    private Asteroids asteroids;

    @BeforeEach
    void setUp() {
        Scoring.resetScore();
        mockPlayer = new Player(SCREEN_WIDTH/2, SCREEN_HEIGHT/2, SCREEN_WIDTH, SCREEN_HEIGHT);
        mockGameStage = Mockito.mock(GameStage.class);
        gameController = new GameController(mockGameStage);
    }

    @Test
    void testInitialScoreIsZero() {
        assertEquals(0, Scoring.getCurrentScore(), "Initial score should be zero.");
        // assertEquals(0, Scoring.getHighestScore(), "Initial high score should be zero.");
    }

    @Test
    void testAddPointsUpdatesScore() {
        Scoring.resetScore();
        Scoring.addPoints(100);
        assertEquals(100, Scoring.getCurrentScore(), "Score should be updated to 10 after adding points.");
    }

    @Test
    public void testSmallAsteroidDestructionScore() throws Exception {
        gameController.handleAsteroidDestruction(new Asteroids(100, 100, 1));
        assertEquals(Scoring.getCurrentScore(), 100, "Asteroid destruction should give expected points");
    }
    @Test
    public void testMediumAsteroidDestructionScore() throws Exception {
        gameController.handleAsteroidDestruction(new Asteroids(200, 100, 2));
        assertEquals(Scoring.getCurrentScore(), 250, "Asteroid destruction should give expected points");
    }
    @Test
    public void testLargeAsteroidDestructionScore() throws Exception {
        gameController.handleAsteroidDestruction(new Asteroids(300, 100, 3));
        assertEquals(Scoring.getCurrentScore(), 500, "Asteroid destruction should give expected points");
    }
    @Test
    public void testSmallMinionDestructionScore() {
        // Assume handleMinionDestruction awards points for minion
        gameController.handleMinionDestruction(new Minion(100, 100, 1, mockPlayer));
        assertEquals(Scoring.getCurrentScore(), 250, "Minion destruction should give expected points");
    }

    @Test
    public void testLargeMinionDestructionScore() {
        gameController.handleMinionDestruction(new Minion(100, 100, 2, mockPlayer));
        assertEquals(Scoring.getCurrentScore(), 500, "Large destruction should give expected points");
    }

    @Test
    public void testBossDestructionScore() {
        // Assume handleBossDestruction awards points for each boss
        gameController.handleBossDestruction(new Boss(200, 200, 1, mockPlayer));
        assertEquals(Scoring.getCurrentScore(), 10000, "Boss destruction should give expected points");
    }

//    @Test
//    void testAddPointsUpdatesHighScore() throws InterruptedException {
//        Scoring.resetScore();
//        Scoring.addPoints(10);
//        assertEquals(10, Scoring.getHighestScore(), "High score should be updated to 10.");
//
//        TimeUnit.SECONDS.sleep(3);// reset combo
//
//        Scoring.addPoints(5);
//        assertEquals(15, Scoring.getHighestScore(), "High score should be updated to 15.");
//    }

//    @Test
//    void testScoringCombo() throws InterruptedException {
//        Scoring.resetScore();
//        Scoring.addPoints(10);
//        Scoring.addPoints(5);
//        assertEquals(2,Scoring.getCombo(),"Combo should be updated to 2.");
//        assertEquals(10+5+(52), Scoring.getCurrentScore(), "Score should be updated to 25.");
//        TimeUnit.SECONDS.sleep(3);
//        Scoring.addPoints(10);
//        assertEquals(10+5+(52)+10,Scoring.getCurrentScore(), "Score should be updated to 35.");
//        assertEquals(1,Scoring.getCombo(),"Combo should be updated to 1.");
//    }

}