package se233.Asteroids_Project.model.Asset;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import se233.Asteroids_Project.model.AllObject;

public class MinionProjectile extends AllObject {
    private static final Logger logger = LogManager.getLogger(MinionProjectile.class);
    private static final double PROJECTILE_SPEED = 7.0;
    private static final double MAX_LIFETIME = 0.7; // seconds

    private double velocityX;
    private double velocityY;
    private double lifetime;
    private boolean isExpired;
    private final double screenWidth;
    private final double screenHeight;

    private static final String Idle = "/se233/Asteroids_Project/asset/player_ship.png";

    public MinionProjectile(double x, double y, double rotation, double screenWidth, double screenHeight) {
        super(Idle, x, y, 8, 8);
        this.rotation = rotation;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.lifetime = 0;
        this.isExpired = false;

        // Calculate velocity based on rotation
        double angleRad = Math.toRadians(rotation);
        this.velocityX = Math.cos(angleRad) * PROJECTILE_SPEED;
        this.velocityY = Math.sin(angleRad) * PROJECTILE_SPEED;

    }

    @Override
    public void update() {
        // Update position
        x += velocityX;
        y += velocityY;

        // Check if projectile goes out of bounds
        if (x < 0 || x > screenWidth || y < 0 || y > screenHeight) {
            isExpired = true; // Mark projectile as expired if it hits the window border
            return;
        }

        // Update lifetime
        lifetime += 0.015; // Assuming 60 FPS
        if (lifetime >= MAX_LIFETIME) {
            isExpired = true;
            return;
        }

        // Wrap around screen
        if (x < 0) x = screenWidth;
        if (x > screenWidth) x = 0;
        if (y < 0) y = screenHeight;
        if (y > screenHeight) y = 0;
    }

    @Override
    public void render(GraphicsContext gc) {
        gc.save();
        // Set the inner fill color
        gc.setFill(Color.ORANGE);
        // Draw the filled oval
        gc.fillOval(x - width / 2, y - height / 2, width, height);

        // Set the outer stroke color
        gc.setStroke(Color.RED); // Change to your desired outer color
        gc.setLineWidth(2); // Set the stroke width
        // Draw the outline of the oval
        gc.strokeOval(x - width / 2, y - height / 2, width, height);

//        double[] xPoints = {0, -width / 4, width / 4};
//        double[] yPoints = {-height / 2, -height, -height};
//        gc.setFill(Color.ORANGE);
//        gc.fillPolygon(xPoints, yPoints, 3); // Nose of the missile

//        gc.setStroke(Color.ORANGE);
//        gc.setLineWidth(1);
//        double trailLength = 10;
//        double angleRad = Math.toRadians(rotation + 180);
//        gc.strokeLine(
//                x, y,
//                x + Math.cos(angleRad) * trailLength,
//                y + Math.sin(angleRad) * trailLength
//        );
        gc.restore();
    }

    public boolean isExpired() {
        return isExpired;
    }
}
