package se233.Asteroids_Project.controller;

public class CollisionHandlingException extends RuntimeException {
    public CollisionHandlingException(String message, Throwable cause) {
        super(message, cause);
    }
}