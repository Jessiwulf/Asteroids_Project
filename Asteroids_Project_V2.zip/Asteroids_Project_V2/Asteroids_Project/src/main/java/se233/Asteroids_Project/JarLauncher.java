package se233.Asteroids_Project;

public class JarLauncher {
    public static void main(String[] args) {
        Launcher.main(args);
    }
}
