package se233.Asteroids_Project.view;

public class MainMenu { // HUD, score display
}
