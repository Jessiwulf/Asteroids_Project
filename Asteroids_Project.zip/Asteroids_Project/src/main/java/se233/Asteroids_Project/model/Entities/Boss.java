package se233.Asteroids_Project.model.Entities;

public class Boss {
}
