package se233.Asteroids_Project.model;

public enum GameState {
    MAINMENU,
    PLAYGROUND,
    GAMEOVER
}