package se233.Asteroids_Project.model;

public class Score { // Score tracking
}
