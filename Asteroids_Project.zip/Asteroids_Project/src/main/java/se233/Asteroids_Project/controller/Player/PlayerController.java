package se233.Asteroids_Project.controller.Player;

import se233.Asteroids_Project.model.PlayerAsset.Player;

public class PlayerController {
    private Player player;
}
