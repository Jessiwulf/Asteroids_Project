package se233.Asteroids_Project.controller.Entities;

public class MinionController {
}
