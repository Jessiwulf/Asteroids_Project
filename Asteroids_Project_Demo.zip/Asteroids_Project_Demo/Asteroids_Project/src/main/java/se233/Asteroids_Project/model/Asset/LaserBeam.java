package se233.Asteroids_Project.model.Asset;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import se233.Asteroids_Project.model.AllObject;

public class LaserBeam extends AllObject {
    private static final Logger logger = LogManager.getLogger(LaserBeam.class);

    private static final String SPRITE_SHEET_PATH = "/se233/Asteroids_Project/asset/Laser.png"; // Adjust the path as needed

    private Image projectileImage;
    private int currentFrame;
    private double animationTimer;
    private static final int FRAME_COUNT = 4;
    private static final double FRAME_DURATION = 0.1;

    private static final double PROJECTILE_SPEED = 15.0;
    private static final double MAX_LIFETIME = 1; // seconds

    private double velocityX;
    private double velocityY;
    private double lifetime;
    private boolean isExpired;
    private final double screenWidth;
    private final double screenHeight;

    public LaserBeam(double x, double y, double rotation, double screenWidth, double screenHeight) {
        super(SPRITE_SHEET_PATH, x, y, 94.5, 200); // Using sprite sheet for the projectile
        this.rotation = rotation;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.lifetime = 0;
        this.isExpired = false;

        // Load the sprite sheet
        projectileImage = new Image(getClass().getResourceAsStream(SPRITE_SHEET_PATH));

        // Calculate velocity based on rotation
        double angleRad = Math.toRadians(rotation);
        this.velocityX = Math.cos(angleRad) * PROJECTILE_SPEED;
        this.velocityY = Math.sin(angleRad) * PROJECTILE_SPEED;

        logger.debug("Projectile created at ({}, {}) with rotation {}", x, y, rotation);
    }

    public boolean intersects(AllObject target) {
        double laserLeft = this.getX() - this.getWidth() / 2;
        double laserRight = this.getX() + this.getWidth() / 2;
        double laserTop = this.getY() - this.getHeight() / 2;
        double laserBottom = this.getY() + this.getHeight() / 2;

        double targetLeft = target.getX() - target.getWidth() / 2;
        double targetRight = target.getX() + target.getWidth() / 2;
        double targetTop = target.getY() - target.getHeight() / 2;
        double targetBottom = target.getY() + target.getHeight() / 2;

        // ตรวจสอบการทับซ้อนระหว่าง LaserBeam และเป้าหมาย
        return laserRight >= targetLeft && laserLeft <= targetRight &&
                laserBottom >= targetTop && laserTop <= targetBottom;
    }

    @Override
    public void update() {
        // Update position
        x += velocityX;
        y += velocityY;
        animationTimer += 0.016; // Assuming 60 FPS

        // Update current frame for animation (if desired)
        if (animationTimer >= FRAME_DURATION) {
            currentFrame = (currentFrame + 1) % FRAME_COUNT;
            animationTimer = 0;
        }

        // Check if projectile goes out of bounds
        if (x < 0 || x > screenWidth || y < 0 || y > screenHeight) {
            isExpired = true; // Mark projectile as expired if it hits the window border
            return;
        }

        // Update lifetime
        lifetime += 0.025; // Assuming 60 FPS
        if (lifetime >= MAX_LIFETIME) {
            isExpired = true;
            return;
        }

        // Wrap around screen
        if (x < 0) x = screenWidth;
        if (x > screenWidth) x = 0;
        if (y < 0) y = screenHeight;
        if (y > screenHeight) y = 0;
    }

    @Override
    public void render(GraphicsContext gc) {
        gc.save(); // Save the current state of the GraphicsContext

        // Move the origin to the projectile's position
        gc.translate(x + width/2, y + height/2);

        // Adjust the rotation angle if needed
        gc.rotate( rotation + 90); // Rotate by (90 - rotation) to correct the direction

        // Draw the projectile centered at (0, 0)
        double sourceX = currentFrame * width;
        // Draw the image centered
        gc.drawImage(projectileImage,
                sourceX, 0, width, height,  // source rectangle (sprite sheet coordinates)
                -width/2, -height/2, width, height  // destination rectangle (screen coordinates)
        );

        gc.restore(); // Restore the previous state of the GraphicsContext
    }

    public boolean isExpired() {
        return isExpired;
    }
}