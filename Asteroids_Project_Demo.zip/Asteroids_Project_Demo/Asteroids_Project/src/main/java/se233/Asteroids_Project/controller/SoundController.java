package se233.Asteroids_Project.controller;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import java.io.File;

public class SoundController {
    private MediaPlayer player;

    public void playSound(String soundFile) {
        try {
            Media sound = new Media(new File(soundFile).toURI().toString());
            player = new MediaPlayer(sound);
            player.play();
        } catch (Exception e) {
            System.err.println("Error playing sound: " + e.getMessage());
        }
    }

    public void stopSound() {
        if (player != null) {
            player.stop();
        }
    }
}

