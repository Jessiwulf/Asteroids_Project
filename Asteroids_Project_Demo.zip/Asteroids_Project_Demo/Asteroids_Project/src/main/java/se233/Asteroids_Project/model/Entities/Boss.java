package se233.Asteroids_Project.model.Entities;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import se233.Asteroids_Project.model.AllObject;

public class Boss extends AllObject {
    private static final Logger logger = LogManager.getLogger(Minion.class);

    private double rotationSpeed;
    private double speedX;
    private double speedY;
    private double speed;

    private int size;
    private int points; // Points awarded when destroyed
    private boolean markedForDestruction;
    private Image bossImage;
    private BossState currentState = BossState.MOVING;

    private int maxHp;
    private int currentHp;

    private static final double SHOOT_COOLDOWN = 1.5; // Seconds between shots
    private double currentShootCooldown = 0;
    private Player targetPlayer;

    private static final String boss1 = "/se233/Asteroids_Project/asset/Boss1_ani.png";

    private int currentFrame;
    private double animationTimer;
    private static final int FRAME_COUNT = 8;
    private static final double FRAME_DURATION = 0.2;

    private static final double HP_BAR_WIDTH = 100;  // Wider bar for boss
    private static final double HP_BAR_HEIGHT = 8;   // Taller bar for boss
    private static final Color HP_BAR_BORDER = Color.WHITE;
    private static final Color HP_BAR_BACKGROUND = Color.TRANSPARENT;
    private static final Color HP_BAR_FILL = Color.MEDIUMVIOLETRED;

    private enum BossState {
        MOVING
    }

    private static final double minDistanceToPlayer =250;

    public Boss(double x, double y, int size, Player player) {
        super(boss1, x, y, 128, 128);
        this.size = size;
        this.markedForDestruction = false;
        this.targetPlayer =  player;
        this.currentShootCooldown = Math.random() * SHOOT_COOLDOWN;
        initializeBoss();
        loadBossImage();
        initializeHp();
    }

    private void loadBossImage() {
        try {
            String imagePath = getImagePathForBossSize(size);
            this.bossImage = new Image(getClass().getResourceAsStream(imagePath));
            if (this.bossImage == null) {
                logger.error("Failed to load enemy image for size: {}", size);
            }
        } catch (Exception e) {
            logger.error("Error loading asteroid image: {}", e.getMessage());
        }
    }

    private static String getImagePathForBossSize(int size) {
        return switch(size) {
            case 1 -> boss1;

            default -> throw new IllegalArgumentException("Invalid enemy image: " + size);
        };
    }



    private static String getBossSize(int size) {
        return switch(size) {
            case 1 -> boss1;

            default -> throw new IllegalArgumentException("Invalid asteroid size: " + size);
        };
    }

    private void initializeBoss() {
        // Random movement direction
//        double angle = Math.random() * Math.PI * 2;
//        double speed = 3 + Math.random() * 2;
        //    double angle = Math.random() * Math.PI * 2;
        this. speed = 3 + Math.random() * 2;

        switch(this.size) {
            case 1:
                speed *= 0.25;
                points = 10000;
//                width = 80;
//                height = 70;
//                initializeAnimation(80,70,1,0.2);
                break;

            default:
                throw new IllegalArgumentException("Invalid enemy size: " + size);
        }


        rotationSpeed = (Math.random() - 0.5) * 20;
        rotation = Math.random() * 360;
    }

    private void initializeHp() {
        switch(this.size) {
            case 1: // Large
                this.maxHp = 10;
                break;

        }
        this.currentHp = this.maxHp;
    }

    // Add method to handle taking damage
    public void takeDamage(int damage) {
        currentHp -= damage;
        if (currentHp <= 0) {
            markForDestructionBoss();
        }
    }

    @Override
    public void update() {
        x += speedX;
        y += speedY;
        currentState = BossState.MOVING;
        animationTimer += 0.016; // Assuming 60 FPS

        if (animationTimer >= FRAME_DURATION) {
            currentFrame = (currentFrame + 1) % FRAME_COUNT;
            animationTimer = 0;
        }

        if (targetPlayer != null && targetPlayer.isAlive()) {

            double dx = targetPlayer.getX() - x;
            double dy = targetPlayer.getY() - y;
            double distance = Math.sqrt(dx * dx + dy * dy);

            // Check if Boss is within minimum distance to player
            if (distance > minDistanceToPlayer) {
                // Move towards player only if distance is greater than the minimum
                x += (dx / distance) * speed;
                y += (dy / distance) * speed;
            }

            double targetAngle = getAngleToPlayer();
            // Smoothly rotate towards player
            double angleDiff = targetAngle - rotation;
            // Normalize angle difference to -180 to 180
            while (angleDiff > 180) angleDiff -= 360;
            while (angleDiff < -180) angleDiff += 360;
            // Rotate towards player with smooth movement
            rotation += Math.signum(angleDiff) * Math.min(Math.abs(angleDiff), 5.0);
        }


        if (currentShootCooldown > 0) {
            currentShootCooldown -= 0.016; // Assuming 60 FPS
        }
        wrapAroundScreen();
    }

    public boolean canShoot() {
        return currentShootCooldown <= 0;
    }

    public void resetShootCooldown() {
        currentShootCooldown = SHOOT_COOLDOWN ;
    }

    public double getAngleToPlayer() {
        if (targetPlayer == null) return rotation;

        double dx = targetPlayer.getX() - x;
        double dy = targetPlayer.getY() - y;
        return Math.toDegrees(Math.atan2(dy, dx));
    }

    private void wrapAroundScreen() {
        if (x < -width) x = 1024;
        if (x > 1024) x = -width;
        if (y < -height) y = 768;
        if (y > 768) y = -height;
    }

    @Override
    public void render(GraphicsContext gc) {
        if (bossImage != null) {
            gc.save();

            gc.translate(x + width/2, y + height/2);
            // Rotate to face player
            gc.rotate(rotation + 90);
            // Calculate the source rectangle for the current frame
            double sourceX = currentFrame * width;
            // Draw the image centered
            gc.drawImage(bossImage,
                    sourceX, 0, width, height,  // source rectangle (sprite sheet coordinates)
                    -width/2, -height/2, width, height  // destination rectangle (screen coordinates)
            );

            gc.restore();
            renderHPBar(gc);

        } else {
            logger.warn("Boss sprite is null, cannot render");
        }
    }
    private void renderHPBar(GraphicsContext gc) {
        // Calculate HP bar position (above the boss)
        double hpBarX = x + (width - HP_BAR_WIDTH) / 2;
        double hpBarY = y - 20;  // 20 pixels above the boss

        // Draw background (empty health)
        gc.setFill(HP_BAR_BACKGROUND);
        gc.fillRect(hpBarX, hpBarY, HP_BAR_WIDTH, HP_BAR_HEIGHT);

        // Draw filled portion
        double fillWidth = (HP_BAR_WIDTH * currentHp) / maxHp;
        gc.setFill(HP_BAR_FILL);
        gc.fillRect(hpBarX, hpBarY, fillWidth, HP_BAR_HEIGHT);

        // Draw border
//        gc.setStroke(HP_BAR_BORDER);
//        gc.setLineWidth(2);  // Thicker border for boss
//        gc.strokeRect(hpBarX, hpBarY, HP_BAR_WIDTH, HP_BAR_HEIGHT);

        // Draw HP text
//        gc.setFill(Color.WHITE);
//        gc.setFont(Font.font("Arial", FontWeight.BOLD, 14));
//        String hpText = currentHp + "/" + maxHp;
//        gc.fillText(hpText, hpBarX + HP_BAR_WIDTH/2 - 15, hpBarY - 5);
    }

    public void markForDestructionBoss() {
        this.markedForDestruction = true;
    }

    public boolean isMarkedForDestructionBoss() {
        return markedForDestruction;
    }

    public int getPointsBoss() {
        return points;
    }

    public int getSize() {
        return size;
    }

    public double getRotationSpeed() {
        return rotationSpeed;
    }

    public void setRotationSpeed(double rotationSpeed) {
        this.rotationSpeed = rotationSpeed;
    }

    public double getSpeedX() {
        return speedX;
    }

    public void setSpeedX(double speedX) {
        this.speedX = speedX;
    }

    public double getSpeedY() {
        return speedY;
    }

    public void setSpeedY(double speedY) {
        this.speedY = speedY;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public boolean isMarkedForDestruction() {
        return markedForDestruction;
    }

    public void setMarkedForDestruction(boolean markedForDestruction) {
        this.markedForDestruction = markedForDestruction;
    }

    public Image getBossImage() {
        return bossImage;
    }

    public void setBossImage(Image bossImage) {
        this.bossImage = bossImage;
    }

    public BossState getCurrentState() {
        return currentState;
    }

    public void setCurrentState(BossState currentState) {
        this.currentState = currentState;
    }

    public int getMaxHp() {
        return maxHp;
    }

    public void setMaxHp(int maxHp) {
        this.maxHp = maxHp;
    }

    public int getCurrentHp() {
        return currentHp;
    }

    public void setCurrentHp(int currentHp) {
        this.currentHp = currentHp;
    }

    public double getCurrentShootCooldown() {
        return currentShootCooldown;
    }

    public void setCurrentShootCooldown(double currentShootCooldown) {
        this.currentShootCooldown = currentShootCooldown;
    }

    public Player getTargetPlayer() {
        return targetPlayer;
    }

    public void setTargetPlayer(Player targetPlayer) {
        this.targetPlayer = targetPlayer;
    }

    public int getCurrentFrame() {
        return currentFrame;
    }

    public void setCurrentFrame(int currentFrame) {
        this.currentFrame = currentFrame;
    }

    public double getAnimationTimer() {
        return animationTimer;
    }

    public void setAnimationTimer(double animationTimer) {
        this.animationTimer = animationTimer;
    }
}
