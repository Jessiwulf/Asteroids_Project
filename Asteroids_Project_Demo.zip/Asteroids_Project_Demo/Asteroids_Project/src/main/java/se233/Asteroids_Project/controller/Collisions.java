package se233.Asteroids_Project.controller;

import javafx.geometry.Bounds;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import se233.Asteroids_Project.model.*;
import se233.Asteroids_Project.model.Asset.PlayerProjectile;
import se233.Asteroids_Project.model.Entities.Asteroids;
import se233.Asteroids_Project.model.Entities.Boss;
import se233.Asteroids_Project.model.Entities.Minion;
import se233.Asteroids_Project.model.Entities.Player;

import java.util.List;

public class Collisions {
    private static final Logger logger = LogManager.getLogger(Collisions.class);
    private static final double COLLISION_MARGIN = 1;

    public static class CollisionHandlingException extends RuntimeException {
        public CollisionHandlingException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * Centralized method to check collision between two objects with exception handling.
     * It calculates the bounds, centers, and applies a collision margin to determine if a collision occurs.
     * @param obj1 First object in the collision check
     * @param obj2 Second object in the collision check
     * @return true if objects collide, false otherwise
     * @throws CollisionHandlingException if any unexpected error occurs during collision checking
     */
    public static boolean checkCollision(AllObject obj1, AllObject obj2) throws CollisionHandlingException {
        try {
            // Retrieve bounds for both objects
            Bounds bounds1 = obj1.getBounds();
            Bounds bounds2 = obj2.getBounds();

            // Apply a collision margin to increase sensitivity for collision detection
            double width1 = bounds1.getWidth() * COLLISION_MARGIN;
            double height1 = bounds1.getHeight() * COLLISION_MARGIN;
            double width2 = bounds2.getWidth() * COLLISION_MARGIN;
            double height2 = bounds2.getHeight() * COLLISION_MARGIN;

            // Calculate center points for both objects
            double centerX1 = bounds1.getMinX() + bounds1.getWidth();
            double centerY1 = bounds1.getMinY() + bounds1.getHeight();
            double centerX2 = bounds2.getMinX() + bounds2.getWidth();
            double centerY2 = bounds2.getMinY() + bounds2.getHeight();

            // Check if distance between centers is less than combined dimensions
            return Math.abs(centerX1 - centerX2) < (width1 + width2) / 2 &&
                    Math.abs(centerY1 - centerY2) < (height1 + height2) / 2;
        } catch (Exception e) {
            // Log and throw a custom exception if collision checking fails
            throw new CollisionHandlingException(
                    String.format("Error checking collision between %s and %s",
                            obj1.getClass().getSimpleName(),
                            obj2.getClass().getSimpleName()), e
            );
        }
    }

    /**
     * Handles collisions between the player and various game objects: asteroids, minions, bosses,
     * and player projectiles. Provides centralized logging and error handling.
     * @param player The player object
     * @param asteroids List of asteroids
     * @param minions List of minions
     * @param boss List of bosses
     * @param playerProjectiles List of player projectiles
     */
    public static void handleCollisions(Player player, List<Asteroids> asteroids, List<Minion> minions, List<Boss> boss, List<PlayerProjectile> playerProjectiles) {
        try {
            // Only proceed with collision checks if the player is vulnerable
            if (!player.isInvulnerable()) {

                // Check for collision between player and each asteroid
                for (Asteroids asteroid : asteroids) {
                    try {
                        if (checkCollision(player, asteroid)) {
                            player.hit();
                            logger.info("Player is hit by asteroid. Lives remaining: {}", player.getLives());
                            break;
                        }
                    } catch (CollisionHandlingException e) {
                        logger.warn("Skipping asteroid collision due to error: {}", e.getMessage());
                    }
                }

                // Check for collision between player and each minion
                for (Minion minion : minions) {
                    try {
                        if (checkCollision(player, minion)) {
                            player.hit();
                            logger.info("Player is hit by enemy. Lives remaining: {}", player.getLives());
                            break;
                        }
                    } catch (CollisionHandlingException e) {
                        logger.warn("Skipping minion collision due to error: {}", e.getMessage());
                    }
                }

                // Check for collision between player and each boss
                for (Boss boss1 : boss) {
                    try {
                        if (checkCollision(player, boss1)) {
                            player.hit();
                            logger.info("Player is hit by boss. Lives remaining: {}", player.getLives());
                            break;
                        }
                    } catch (CollisionHandlingException e) {
                        logger.warn("Skipping boss collision due to error: {}", e.getMessage());
                    }
                }
            }

            // Handle any errors that occur during collision checks
        } catch (CollisionHandlingException e) {
            logger.error("Collision handling error: {}", e.getMessage(), e);
        }
    }
}
