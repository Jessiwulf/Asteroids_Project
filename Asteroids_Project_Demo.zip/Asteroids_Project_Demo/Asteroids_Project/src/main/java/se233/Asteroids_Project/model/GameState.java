package se233.Asteroids_Project.model;

public enum GameState {
    MAIN_MENU,
    PLAYGROUND,
    GAME_OVER
}
