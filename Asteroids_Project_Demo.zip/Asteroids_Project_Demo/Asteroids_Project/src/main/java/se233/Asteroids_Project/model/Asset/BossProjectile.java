package se233.Asteroids_Project.model.Asset;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import se233.Asteroids_Project.model.AllObject;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import se233.Asteroids_Project.model.AllObject;

public class BossProjectile extends AllObject {
    private static final Logger logger = LogManager.getLogger(BossProjectile.class);

    private static final String SPRITE_SHEET_PATH = "/se233/Asteroids_Project/asset/Boss_Attack1.png"; // Adjust the path as needed
    private Image projectileImage;
    private int currentFrame;
    private double animationTimer;
    private static final int FRAME_COUNT = 4;
    private static final double FRAME_DURATION = 0.2;
    private static final double PROJECTILE_SPEED = 5.0;
    private static final double MAX_LIFETIME = 1.5; // seconds

    private double velocityX;
    private double velocityY;
    private double lifetime;
    private boolean isExpired;
    private final double screenWidth;
    private final double screenHeight;

    // pattern
    private final ProjectilePattern pattern;

    public enum ProjectilePattern {
        STRAIGHT,
        MULTI_SHOT
    }

    private static final String Idle = "/se233/Asteroids_Project/asset/player_ship.png";

    public BossProjectile(double x, double y, double rotation, double screenWidth, double screenHeight, ProjectilePattern pattern) {
        super(Idle, x, y, 16.5, 11); // Small projectile size
        this.rotation = rotation;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.lifetime = 0;
        this.isExpired = false;
        this.pattern = pattern;

        // Load the sprite sheet
        projectileImage = new Image(getClass().getResourceAsStream(SPRITE_SHEET_PATH));

        // Calculate velocity based on rotation
        double angleRad = Math.toRadians(rotation);
        this.velocityX = Math.cos(angleRad) * PROJECTILE_SPEED;
        this.velocityY = Math.sin(angleRad) * PROJECTILE_SPEED;

       initializePattern(rotation);
    }
    private void initializePattern(double rotation) {
        double angleRad = Math.toRadians(rotation);
        switch (pattern) {
            case STRAIGHT:
            case MULTI_SHOT:
                this.velocityX = Math.cos(angleRad) * PROJECTILE_SPEED;
                this.velocityY = Math.sin(angleRad) * PROJECTILE_SPEED;
                break;

        }
    }


    @Override
    public void update() {

        switch (pattern) {
            case STRAIGHT:
                updateStraight();
            case MULTI_SHOT:
                x += velocityX;
                y += velocityY;
                break;
        }

        animationTimer += 0.016; // Assuming 60 FPS
        // Update current frame for animation (if desired)
        if (animationTimer >= FRAME_DURATION) {
            currentFrame = (currentFrame + 1) % FRAME_COUNT;
            animationTimer = 0;
        }

        // Check if projectile goes out of bounds
        if (x < 0 || x > screenWidth || y < 0 || y > screenHeight) {
            isExpired = true; // Mark projectile as expired if it hits the window border
            return;
        }

        // Update lifetime
        lifetime += 0.020; // Assuming 60 FPS
        if (lifetime >= MAX_LIFETIME) {
            isExpired = true;
            return;
        }

        // Wrap around screen
        if (x < 0) x = screenWidth;
        if (x > screenWidth) x = 0;
        if (y < 0) y = screenHeight;
        if (y > screenHeight) y = 0;

    }
    private void updateStraight() {
      x += velocityX;
      y += velocityY;
    }


    @Override
    public void render(GraphicsContext gc) {
        gc.save();

        // Move the origin to the projectile's position
        gc.translate(x + width/2, y + height/2);

        // Adjust the rotation angle if needed
        gc.rotate( rotation ); // Rotate by (90 - rotation) to correct the direction

        // Draw the projectile centered at (0, 0)
        double sourceX = currentFrame * width;
        // Draw the image centered
        gc.drawImage(projectileImage,
                sourceX, 0, width, height,  // source rectangle (sprite sheet coordinates)
                -width/2, -height/2, width, height  // destination rectangle (screen coordinates)
        );

//        gc.setFill(Color.MEDIUMVIOLETRED);
//        gc.fillOval(x - width/2, y - height/2, width, height);
//
//        // Optional: Add trailing effect
//        gc.setStroke(Color.HOTPINK);
//        gc.setLineWidth(1);
//        double trailLength = 8;
//        double angleRad = Math.toRadians(rotation + 180);
//        gc.strokeLine(
//                x, y,
//                x + Math.cos(angleRad) * trailLength,
//                y + Math.sin(angleRad) * trailLength
//        );
        gc.restore();
    }

    public boolean isExpired() {
        return isExpired;
    }

    public static BossProjectile[] createMultiShotPattern(double x, double y, double rotation,
                                                          double screenWidth, double screenHeight,
                                                          int bulletCount, double spreadAngle) {
        BossProjectile[] projectiles = new BossProjectile[bulletCount];

        // Calculate the angle between each bullet
        double angleStep = spreadAngle / (bulletCount - 1);
        // Calculate the starting angle to center the spread
        double startAngle = rotation - (spreadAngle / 2);

        for (int i = 0; i < bulletCount; i++) {
            // Calculate the angle for this bullet
            double bulletAngle = startAngle + (angleStep * i);

            projectiles[i] = new BossProjectile(
                    x, y,  // All bullets start from the same point
                    bulletAngle,  // Each bullet has a different angle
                    screenWidth, screenHeight,
                    ProjectilePattern.MULTI_SHOT
            );
        }

        return projectiles;
    }
}
