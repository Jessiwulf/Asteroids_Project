package se233.Asteroids_Project;

import org.junit.jupiter.api.TestInstance;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({AsteroidsMovementTest.class, BossMovementTest.class, BossShootingTest.class,EnemyMovementTest.class
        , EnemyShootingTest.class, PlayerMovementsTest.class, PlayerShootingTest.class, ShootingTest.class, ScoringTest.class})
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class JUnitTestSuite {

}
