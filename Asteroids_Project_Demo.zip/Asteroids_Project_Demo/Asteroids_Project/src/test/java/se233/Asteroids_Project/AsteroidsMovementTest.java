package se233.Asteroids_Project;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import se233.Asteroids_Project.model.Entities.Asteroids;

import static org.junit.jupiter.api.Assertions.*;

public class AsteroidsMovementTest {
    private Asteroids asteroid;
    private static final double DELTA = 0.001; // Delta for floating point comparisons

    @BeforeEach
    void setUp() {
        // Initialize a test asteroid at position (100, 100) with size 1 (Large)
        asteroid = new Asteroids(100.0, 100.0, 1);
    }

    @Test
    void testInitialPosition() {
        assertEquals(100.0, asteroid.getX(), DELTA, "Initial X position should be 100.0");
        assertEquals(100.0, asteroid.getY(), DELTA, "Initial Y position should be 100.0");
    }

    @Test
    void testMovement() {
        // Store initial position
        double initialX = asteroid.getX();
        double initialY = asteroid.getY();

        // Update position
        asteroid.update();

        // Position should change due to speedX and speedY
        assertNotEquals(initialX, asteroid.getX(), "Asteroid should move in X direction");
        assertNotEquals(initialY, asteroid.getY(), "Asteroid should move in Y direction");
    }

    @Test
    void testScreenWrappingRight() {
        // Place asteroid near right edge
        Asteroids rightAsteroid = new Asteroids(1023.0, 100.0, 1); // Adjusted for screen width of 1024

        // Force movement to the right
        for (int i = 0; i < 10; i++) {
            rightAsteroid.update();
        }

        // Check if asteroid wrapped around
        assertTrue(rightAsteroid.getX() < 1024.0, "Asteroid should wrap around when moving past right edge");
    }


    @Test
    void testScreenWrappingLeft() {
        // Place asteroid near left edge
        Asteroids leftAsteroid = new Asteroids(1.0, 100.0, 1);

        // Force movement to the left
        for (int i = 0; i < 10; i++) {
            leftAsteroid.update();
        }

        // Check if asteroid wrapped around
        assertTrue(leftAsteroid.getX() > -70.0, "Asteroid should wrap around when moving past left edge");
    }

    @Test
    void testScreenWrappingTop() {
        // Place asteroid near top edge
        Asteroids topAsteroid = new Asteroids(100.0, 1.0, 1);

        // Force movement upward
        for (int i = 0; i < 10; i++) {
            topAsteroid.update();
        }

        // Check if asteroid wrapped around
        assertTrue(topAsteroid.getY() > -70.0, "Asteroid should wrap around when moving past top edge");
    }

    @Test
    void testScreenWrappingBottom() {
        // Place asteroid near bottom edge
        Asteroids bottomAsteroid = new Asteroids(100.0, 599.0, 1);

        // Force movement downward
        for (int i = 0; i < 10; i++) {
            bottomAsteroid.update();
        }

        // Check if asteroid wrapped around
        assertTrue(bottomAsteroid.getY() < 600.0, "Asteroid should wrap around when moving past bottom edge");
    }

    @Test
    void testRotation() {
        double initialRotation = asteroid.getRotation();
        asteroid.update();
        assertNotEquals(initialRotation, asteroid.getRotation(), "Asteroid should rotate over time");
    }

    @Test
    void testSizeInitialization() {
        // Test size 1 (Small)
        Asteroids smallAsteroid = new Asteroids(100.0, 100.0, 1);
        assertEquals(1, smallAsteroid.getSize(), "Asteroid size should be 1 (Large)");
        assertEquals(25.0, smallAsteroid.getWidth(), DELTA, "Large asteroid should have width 25.0");

        // Test size 2 (Medium)
        Asteroids mediumAsteroid = new Asteroids(100.0, 100.0, 2);
        assertEquals(2, mediumAsteroid.getSize(), "Asteroid size should be 2 (Medium)");
        assertEquals(50.0, mediumAsteroid.getWidth(), DELTA, "Medium asteroid should have width 50.0");

        // Test size 2 (Medium)
        Asteroids largeAsteroid = new Asteroids(100.0, 100.0, 3);
        assertEquals(3, largeAsteroid.getSize(), "Asteroid size should be 2 (Medium)");
        assertEquals(100.0, largeAsteroid.getWidth(), DELTA, "Medium asteroid should have width 100.0");
    }

    @Test
    void testInvalidSize() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Asteroids(100.0, 100.0, 4);
        }, "Creating asteroid with invalid size should throw IllegalArgumentException");
    }
}