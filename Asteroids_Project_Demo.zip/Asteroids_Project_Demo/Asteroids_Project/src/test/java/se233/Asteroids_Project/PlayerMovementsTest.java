package se233.Asteroids_Project;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import se233.Asteroids_Project.model.Entities.Player;
import se233.Asteroids_Project.controller.GameController;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class PlayerMovementsTest {
    private Player player;
    private final double SCREEN_WIDTH = 800;
    private final double SCREEN_HEIGHT = 600;
    private final double DELTA = 0.01;
    private final double INITIAL_ROTATION = -90;
    private GameController gameController;

    @BeforeEach
    public void setUp() {
        // Initialize player at center of screen
        player = new Player(SCREEN_WIDTH/2, SCREEN_HEIGHT/2, SCREEN_WIDTH, SCREEN_HEIGHT);
    }
    @Test
    public void testInitialPosition() {
        assertEquals(SCREEN_WIDTH / 2, player.getX(), DELTA, "Player X position should be at center.");
        assertEquals(SCREEN_HEIGHT / 2, player.getY(), DELTA, "Player Y position should be at center.");
        assertEquals(INITIAL_ROTATION, player.getRotation(), DELTA, "Player should be initialized at rotation of -90 degrees.");
    }

    @Test
    public void testMovementBackward() {
        player.setMovingBackward(true);
        player.update();  // Call update to apply movement
        assertTrue(player.getY() > SCREEN_HEIGHT / 2, "Player should move backward when pressing backward.");
        player.setMovingBackward(false);  // Reset state after test
    }
    @Test
    public void testMovementForward() {
        player.setMovingForward(true);
        player.update();  // Call update to apply movement
        assertTrue(player.getY() < SCREEN_HEIGHT / 2, "Player should move forward when pressing forward.");
        player.setMovingForward(false);  // Reset state after test
    }
    @Test
    public void testMovementLeft() {
        player.setMovingLeft(true);
        player.update();  // Call update to apply movement
        assertTrue(player.getX() < SCREEN_WIDTH / 2, "Player should move left when pressing left.");
        player.setMovingLeft(false);  // Reset state after test
    }

    @Test
    public void testMovementRight() {
        player.setMovingRight(true);
        player.update();  // Call update to apply movement
        assertTrue(player.getX() > SCREEN_WIDTH / 2, "Player should move right when pressing right.");
        player.setMovingRight(false);  // Reset state after test
    }

}