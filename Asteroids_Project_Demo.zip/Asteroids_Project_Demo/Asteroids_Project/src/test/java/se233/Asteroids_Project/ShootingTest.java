package se233.Asteroids_Project;

import org.junit.jupiter.api.BeforeEach;
import se233.Asteroids_Project.model.Entities.Player;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ShootingTest {
    private Player player;
    private static final double STAGE_WIDTH = 800;
    private static final double STAGE_HEIGHT = 600;
    private static final double DELTA = 0.001;

    @BeforeEach
    void setUp() {
        // Create a player at the center of the stage
        player = new Player(STAGE_WIDTH/2, STAGE_HEIGHT/2, STAGE_WIDTH, STAGE_HEIGHT);
    }
    @Test
    void testCanShootInitially() {
        // Verify that the player can shoot initially
        assertTrue(player.canShoot(), "Player should be able to shoot initially.");
    }
    @Test
    void testShootResetsCooldown() {
        // Shoot once and check if cooldown is reset
        player.resetShootCooldown();
        assertFalse(player.canShoot(), "Player should not be able to shoot immediately after shooting.");
    }

    @Test
    void testCooldownTimerUpdates() {
        // Shoot and then update to simulate time passing
        player.resetShootCooldown();
        player.update();
        assertFalse(player.canShoot(), "Cooldown should still be in effect right after shooting.");

        // Simulate waiting until cooldown is complete
        for (int i = 0; i < 16; i++) { // Assuming update runs at 60 FPS, wait approximately 250ms
            player.update();
        }
        assertTrue(player.canShoot(), "Player should be able to shoot after cooldown period.");
    }


    @Test
    void testContinuousShootingDisallowed() {
        // Try shooting continuously, cooldown should prevent shooting multiple times in a row
        player.resetShootCooldown(); // First shot
        assertFalse(player.canShoot(), "Cooldown should prevent immediate re-shooting.");

        // Simulate updating until cooldown completes
        for (int i = 0; i < 16; i++) {
            player.update();
        }

        assertTrue(player.canShoot(), "Player should be able to shoot again after cooldown.");
    }

}